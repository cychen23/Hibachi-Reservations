import os
import requests
import urllib.parse

from flask import redirect, render_template, request, session
from functools import wraps

def apology(message, code=400):
    """Render message as an apology to user."""
    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [("-", "--"), (" ", "-"), ("_", "__"), ("?", "~q"),
                         ("%", "~p"), ("#", "~h"), ("/", "~s"), ("\"", "''")]:
            s = s.replace(old, new)
        return s
    return render_template("apology.html", top=code, bottom=escape(message)), code

# Returns number of empty seats at table
def count_f(day, time, table_num, days):
    cur_table = days[day][time][table_num]
    count = 0
    for seat in cur_table:
        # If seat is empty, add one to count
        if seat == False:
            count+=1
    return count


# Returns number of the first available table, and None if there aren't any available
def table_availability(day, time, num_people, days):
    for table_num in range(6):
        # Checks if there are enough empty seats at the current table
        if count_f(day, time, table_num, days) >= num_people:
            return table_num
    return None

# Used for reservations with >= 8 people #should be just those over 8?
# Returns number of the first available table, and None if there aren't any
def overflow(day, time, num_people, days):
    for cur_table in [0,2,4]:
        while True:
            if count_f(day, time, cur_table, days) == 8:
                if count_f(day, time, cur_table + 1, days) >= num_people - 8:
                    # cur_table will seat 8
                    # cur_table+1 will seat the extra people
                    return cur_table
            elif count_f(day, time, cur_table + 1, days) == 8:
                if count_f(day, time, cur_table, days) >= num_people -8:
                    # cur_table+1 will seat 8
                    # cur_table will seat the extra people
                    return cur_table + 1
            else:
                break
    return None

# Changes seat availability from open to taken
def false_to_true(table_number, day, time, num_people, days):
    count = num_people

    for i in range(8):
        if count <= 0:
            break
        elif days[day][time][table_number][i] == False:
            # Changes seat availability
            days[day][time][table_number][i] = True

            # Subtracts one from counter
            count-=1
    return True

# Changes seat availability from taken to open
def true_to_false(table_number, day, time, num_people, days):
    count = num_people

    for i in range(8):
        if count <= 0:
            break
        elif days[day][time][table_number][i] == True:
            # Changes seat availability
            days[day][time][table_number][i] = False

            # Subtracts one from counter
            count-=1
    return True


