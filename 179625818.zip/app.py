import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp

from helpers import count_f, table_availability, overflow, apology, false_to_true, true_to_false

# Configure application
app = Flask(__name__)

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///tables.db")

# Initializes global dictionary containing entry data that will be referenced between multiple pages
cur = {
    'day':None,
    'number_of_people':None
}

# Creates empty dictionary days
days = {}

days["Friday"] = []
days["Saturday"] = []

# Creates time and table lists within days

# 9 different times for each day
for time in range(9):
    days["Friday"].append([])
    days["Saturday"].append([])
    # 6 tables for each time
    for table in range(6):
        # Adds a new table to current time
        # Adds 8 empty seats to the newly added table
        days["Friday"][time].append([False] * 8)
        days["Saturday"][time].append([False] * 8)


# Creates dictionaries to easily convert time indices (0-8) to string values ("4:30"-"8:30")
# and vice versa. Times will be stored using numbers for simplicity, but
# displayed as time stamps to users
times_text = {
    0:"4:30",
    1:"5:00",
    2:"5:30",
    3:"6:00",
    4:"6:30",
    5:"7:00",
    6:"7:30",
    7:"8:00",
    8:"8:30"
}

times_num = {
    "4:30":0,
    "5:00":1,
    "5:30":2,
    "6:00":3,
    "6:30":4,
    "7:00":5,
    "7:30":6,
    "8:00":7,
    "8:30":8
}



@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response



@app.route("/check_avail", methods=["GET","POST"])
def check_avail():
    #loads the page when requested
    if request.method == "GET":
        return render_template("check_avail.html")

    #stores submitted data
    else:

        date = request.form.get("date")
        num = request.form.get("number_people")

        # Checks if date is valid
        if not date:
            return apology("date is empty")
        elif date != "Friday" and date != "Saturday":
            return apology("please enter a valid date")

        # Checks if num is valid
        if not num:
            return apology("number of people is empty")
        elif not num.isnumeric():
            return apology("please enter a number")
        elif int(num) > 16:
            return apology("please call for large groups (more than 16)")


        # Clears any old stored values
        cur['day'] = None
        cur['number_of_people'] = None

        # Updates variables to new values
        cur['day'] = request.form.get("date")
        cur['number_of_people'] = int(request.form.get("number_people"))

        #Check if data was entered
        if not cur['number_of_people']:
            return apology("Please enter number of people")

        if not cur['day']:
            return apology("Please enter Friday or Saturday")

        return redirect("/submit")


@app.route("/submit", methods=["GET","POST"])
def submit():

    # When the page loads, it should use the information entered in check_avail,
    # look for avaliable reservations, and then return all the times that
    # there are avaliable reservations
    day = cur['day']
    number_people = cur['number_of_people']

    if request.method == "GET" and number_people is not None and day is not None:

        # checks what time are available if the table number is 8 or under
        if number_people <= 8:
            avail_times = []
            for time in range(8):
                table_num = table_availability(day, time, number_people, days)
                if table_num != None:
                    avail_times.append(times_text[time])


        if number_people > 8:
            avail_times = []
            for time in range(8):
                table_num = overflow(day, time, number_people, days)
                if table_num != None:
                    avail_times.append(times_text[time])

        # returns all avaliable times in a list
        return render_template("submit.html", avail_times=avail_times[:], date=day, number_people=number_people)


    elif request.method == "POST":

        name = request.form.get("name")
        # Check if name is alphanumeric
        if not name:
            return apology("name is empty")
        elif not name.isalnum():
            return apology("name is not alphanumeric")

        day = request.form.get("date")
        # Checks if date is valid
        if not day:
            return apology("date is empty")
        elif day != "Friday" and day != "Saturday":
            return apology("invalid date")

        # placeholder num
        num = request.form.get("number_people")
        # Checks if number of people is valid
        if not num:
            return apology("number of people is empty")
        elif int(num) > 16:
            return apology("please call for large groups (more than 16)")

        number_people = int(request.form.get("number_people"))

        time = request.form.get("time")
        if not time:
            return apology("time not selected")
        time = times_num[request.form.get("time")]

        # if not a overflow table(aka a table over 8 people, which requires 2 tables)
        if number_people <= 8:
            table_number = table_availability(day, time, number_people, days)

            # double check that table is available
            if table_number == None:
                return apology("no available tables")

            # Update tables to be filled, and record reservation in database

            # For first 30 mins (reversation time)
            false_to_true(table_number, day, time, number_people, days)
            # For second 30 mins (reservation time + 30 mins)
            # number of people is 8, because the table is closed no matter what after 15 minutes have past
            if time != 8:
                false_to_true(table_number, day, time + 1, 8, days)

            db.execute("INSERT INTO reservations (name, number, table_num, time, day) VALUES (?, ?, ?, ?, ?)",
                name, number_people, table_number, time, day)

            return redirect("/home")

        # in cases where more than 2 tables are required, aka where number of people is over 8,
        # two consequtive tables have to be found.
        if number_people > 8:
            # Find the table where 8 will be seated
            full_table_number = overflow(day, time, number_people, days)

            # find the table where the remaining will be seated
            # since the function looks by checking table blocks(2 tables per block),
            # and only returns the specific table that holds 8
            # if that table is odd, the overflow table numbered 1 below
            # if the table is even, the overflow table will be numbered 1 higher
            if full_table_number % 2 == 0:
                overflow_table_number = full_table_number + 1
            else:
                overflow_table_number = full_table_number - 1

            # Update the specified tables to be filled

            # For first 30 mins (reversation time)
            false_to_true(full_table_number, day, time, 8, days)
            false_to_true(overflow_table_number, day, time, number_people - 8, days)
            # For second 30 mins (reservation time + 30 mins)
            if time != 8:
                false_to_true(full_table_number, day, time + 1, number_people, days)

                # when there is a overflow table, if there is only 3 or less overflow, you can still treat it as an "empty"
                # table at the next time stamp. Over that, however, and you have to treat it as full
                if (number_people - 8) <= 3:
                    false_to_true(overflow_table_number, day, time + 1, number_people, days)
                else:
                    false_to_true(overflow_table_number, day, time + 1, 8, days)


            # Record in database the reservation information
            # Record two based on full/overflow table so the host knows exactly
            # where to seat people
            db.execute("INSERT INTO reservations (name, number, table_num, time, day) VALUES (?, ?, ?, ?, ?)",
                name, 8, full_table_number, time, day)


            # The -8 is so it lists how many people are specifically at the overflow table
            db.execute("INSERT INTO reservations (name, number, table_num, time, day) VALUES (?, ?, ?, ?, ?)",
                name, number_people - 8, overflow_table_number, time, day)

            return redirect("/home")
    else:
        return apology("sorry")


@app.route("/")
def home():
    return redirect("/home")

@app.route("/home")
def home2():

    reservations = db.execute("SELECT name, number, table_num, time, day FROM reservations ORDER BY day, time, name")

    # converts the times from numerical(stored as 0, 1, etc.) to text easily understandable to the user
    for reservation in reservations:
        reservation.update({"time": times_text[int(reservation["time"])]})

    return render_template("home.html", reservations=reservations)

@app.route("/delete", methods=["GET","POST"])
def delete():

    if request.method == "POST":

        # stores values of requested information
        name = request.form.get("name")
        day = request.form.get("date")
        number_people = request.form.get("number_people")
        time = request.form.get("time")

        # return apology if things were not submitted and updates variables if they were
        if not name:
            return apology("name is empty")
        if not day:
            return apology("day not selected")
        if not number_people:
            return apology("number of people not entered")
        number_people = int(request.form.get("number_people"))
        if not time:
            return apology("time not selected")
        time = times_num[request.form.get("time")]

        # Finds the row of the inputted data, and deletes it
        if number_people <= 8:
            id = db.execute("SELECT reservation_id, table_num FROM reservations WHERE name = ? AND number = ? AND day = ? AND time = ? ", name, number_people, day, time)

            # sends error message if reservation does not exist
            if not id:
                return apology("Reservation does not exist")

            #updates table values
            # since id is a list of a dictionary, you have to index into the first item in the list and then the value associated with the reservation id
            true_to_false(id[0]["table_num"], day, time, number_people, days)

            # if after a reservation is deleted, the table is completely empty, it needs to reopen the table at the next half hour block
            if count_f(day, time, id[0]["table_num"], days) == 8:
                true_to_false(id[0]["table_num"], day, time + 1, number_people, days)


            # deletes reservation from SQL database
            db.execute("DELETE FROM reservations WHERE reservation_id = ?", id[0]["reservation_id"])

        else:
            # Since the SQL database stores overflow tables in two seperate rows, one with 8 people and
            # and the other with the overflow people, the process to delete the reservation is different

            # Finds the number of overflow people
            number_of_overflow = number_people - 8

            # Finds id of table with table of 8
            id = db.execute("SELECT reservation_id, table_num FROM reservations WHERE name = ? AND number = ? AND day = ? AND time = ? ", name, 8, day, time)

            # sends error message if reservation does not exist
            if not id:
                return apology("Reservation does not exist")

            # updates table
            true_to_false(id[0]["table_num"], day, time, 8, days)
            true_to_false(id[0]["table_num"], day, time + 1, 8, days)

            # Removes reservation from database
            db.execute("DELETE FROM reservations WHERE reservation_id = ?", id[0]["reservation_id"])

            # Finds id of table with overflow people and deletes it
            id = db.execute("SELECT reservation_id, table_num FROM reservations WHERE name = ? AND number = ? AND day = ? AND time = ? ", name, number_of_overflow, day, time)

            # updates tables to be empty and removes from SQL database
            true_to_false(id[0]["table_num"], day, time, number_of_overflow, days)

            if count_f(day, time, id[0]["table_num"], days) == 8:
                true_to_false(id[0]["table_num"], day, time + 1, number_people, days)

            db.execute("DELETE FROM reservations WHERE reservation_id = ?", id[0]["reservation_id"])

        return redirect("/home")


    else:
        # feeds the list of times to create the drop down menu in the html page
        return render_template("delete.html", times=times_num.keys())

