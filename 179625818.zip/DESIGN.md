# Design Document

## Technical Decisions
### In this section, share and justify the technical decisions you made.

One of the first design challenges we ran into was storing the data for table availability. Since these values would need to be stored and referenced for different days, times, and tables, we wanted to figure out how to structure the data such that accessing individual seat values would be easy. For each table, we used a list to store a boolean value for each of the 8 seats. For each time, a list stores each of the 6 table lists. For each day, a list stores the table lists for each of the 9 times (4:30 to 8:30, inclusive). A dictionary called days stored each day as keys (currently only “Friday” and “Saturday,” since those are the most important days for reservations at Koto). This nested structure allowed us to store everything in one data structure (the days dictionary) while still being able to access all the information.

In terms of the website layout and structure, we wanted to prioritize conciseness and ease of use. The main functionality of our website is to allow the host/hostess to input a reservation size and be able to check 1) what times are available, and 2) what table number the reservation should be seated at. If we separated the reservation system into two tabs, Check Availability and Submit Reservation, then in the case that a reservation cannot be made at the specified time, the user would have to go back to Check Availability to find all available times, then Submit Reservation to submit the reservation at a different time. This requires three steps, compared to the (constant) two steps it would take for our current structure. Users go to Check Availability to search for all available times, which redirects them to the form to submit a reservation, which has available times displayed along with day and number of people autofilled.

For inputting the day and time, we made them dropdown menus instead of text boxes, since it takes longer to type than to click. This also minimizes the possibility of invalid inputs.

Submit Reservations(“submit.html”) works as follows. When the page is requested through “get,” it calls table_availability(), which returns true if a table is available at a given time and false if not. Submit.html calls this function for every time slot on a given day, and displays the times where true was returned. Table_availability works by counting the number of available seats at every table(using count_f()) and comparing it to the number of people needed to be seated. It returns true once it finds a table that has space available.

However, in the special case where a table is over 8 people, submit.html instead calls overflow() instead of table_availability(). A special function is needed because parties of 8 or more must be seated at two tables rather than just one, and they should be seated at the same hibachi table (there are two tables that make up each hibachi table).

When submit.html is posted, aka a user submits a reservation to be recorded, it follows the same process as described before, in order to double check that a reservation is available (in case that some information was altered). If a table is still available, it updates the SQL database to record the reservation and redirects the user to the home page.

We also considered the fact that the host/hotstess would be taught how to use the website (i.e., how to format entries). This allowed us to have more flexibilities with minor details in checking inputs, though more common/larger mistakes are still accounted for in the code using apologies.

## Ethical Decisions
### What motivated you to complete this project? What features did you want to create and why?

Our project is a website that allows the hosts of Koto, a Hibachi restaurant owned by my (Carly’s) parents, to make reservations. I’ve been a host at the restaurant for a few years and in doing and teaching others the job, one of the hardest things to learn was the hibachi reservation system. It has a very complicated set of rules and things to factor for all at once, and essentially the only person who really understood it consistently was my dad. We made a project to help ameliorate this situation, by creating a program that can figure out when reservations are available for you. Therefore, our main feature is to allow the hosts to input reservation details — date and size of party — into the program, which then checks if there are available times for the party given the date and size. If there are, the program outputs the available times.

### Who are the intended users of your project? What do they want, need, or value?
You should consider your project's users to be those who interact _directly_ with your project, as well as those who might interact with it _indirectly_, through others' use of your project.

Its use is intended for the owners of Koto to more easily plan seating and timing. In use, however, it is intended for hosts, whether experienced or new. The host will want an uncomplicated program that will be easy to use during busy rush hours. Since the end goal is to make reservations for them, they also want a program that is accurate in order to avoid angering customers.


### How does your project's impact on users change as the project scales up?

We tried to make the website as user-friendly as possible so that the host/hostess of the restaurant would not have trouble incorporating it. However, given the nature of Hibachi reservations and the guidelines that this specific restaurant follows, it could be difficult for other restaurants to try to use the website to record reservations.
